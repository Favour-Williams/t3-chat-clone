"use client";

import { useState, useRef } from "react";
import { Send, Square, Paperclip, Settings } from "lucide-react";

interface MessageInputProps {
  onSendMessage: (content: string, provider: string, model: string) => void;
  isStreaming: boolean;
  onStopGeneration: () => void;
}

const LLM_PROVIDERS = {
  openrouter: {
    name: "OpenRouter",
    models: [
      "openai/gpt-4",
      "openai/gpt-3.5-turbo",
      "anthropic/claude-3-haiku",
      "meta-llama/llama-2-70b-chat",
    ],
  },
  groq: {
    name: "Groq",
    models: [
      "mixtral-8x7b-32768",
      "llama2-70b-4096",
      "gemma-7b-it",
    ],
  },
  huggingface: {
    name: "Hugging Face",
    models: [
      "microsoft/DialoGPT-medium",
      "facebook/blenderbot-400M-distill",
      "microsoft/DialoGPT-large",
    ],
  },
};

export default function MessageInput({
  onSendMessage,
  isStreaming,
  onStopGeneration,
}: MessageInputProps) {
  const [message, setMessage] = useState("");
  const [selectedProvider, setSelectedProvider] = useState("openrouter");
  const [selectedModel, setSelectedModel] = useState(LLM_PROVIDERS.openrouter.models[0]);
  const [showSettings, setShowSettings] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (message.trim() && !isStreaming) {
      onSendMessage(message.trim(), selectedProvider, selectedModel);
      setMessage("");
      if (textareaRef.current) {
        textareaRef.current.style.height = "auto";
      }
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e);
    }
  };

  const handleTextareaChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setMessage(e.target.value);
    
    // Auto-resize textarea
    const textarea = e.target;
    textarea.style.height = "auto";
    textarea.style.height = `${Math.min(textarea.scrollHeight, 200)}px`;
  };

  const handleProviderChange = (provider: string) => {
    setSelectedProvider(provider);
    setSelectedModel(LLM_PROVIDERS[provider as keyof typeof LLM_PROVIDERS].models[0]);
  };

  return (
    <div className="border-t border-gray-200 bg-white">
      {/* Settings Panel */}
      {showSettings && (
        <div className="p-4 border-b border-gray-200 bg-gray-50">
          <div className="max-w-4xl mx-auto">
            <h3 className="text-sm font-medium text-gray-700 mb-3">LLM Settings</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Provider
                </label>
                <select
                  value={selectedProvider}
                  onChange={(e) => handleProviderChange(e.target.value)}
                  className="w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                >
                  {Object.entries(LLM_PROVIDERS).map(([key, provider]) => (
                    <option key={key} value={key}>
                      {provider.name}
                    </option>
                  ))}
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Model
                </label>
                <select
                  value={selectedModel}
                  onChange={(e) => setSelectedModel(e.target.value)}
                  className="w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                >
                  {LLM_PROVIDERS[selectedProvider as keyof typeof LLM_PROVIDERS].models.map((model) => (
                    <option key={model} value={model}>
                      {model}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Input Area */}
      <div className="p-4">
        <div className="max-w-4xl mx-auto">
          <form onSubmit={handleSubmit} className="flex gap-2">
            <div className="flex-1 relative">
              <textarea
                ref={textareaRef}
                value={message}
                onChange={handleTextareaChange}
                onKeyDown={handleKeyDown}
                placeholder="Type your message..."
                className="w-full p-3 pr-12 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 resize-none"
                style={{ minHeight: "48px", maxHeight: "200px" }}
                disabled={isStreaming}
              />
              
              <button
                type="button"
                className="absolute right-3 top-3 p-1 text-gray-400 hover:text-gray-600 transition-colors"
              >
                <Paperclip size={20} />
              </button>
            </div>
            
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setShowSettings(!showSettings)}
                className={`p-3 rounded-lg transition-colors ${
                  showSettings
                    ? "bg-indigo-600 text-white"
                    : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                }`}
              >
                <Settings size={20} />
              </button>
              
              {isStreaming ? (
                <button
                  type="button"
                  onClick={onStopGeneration}
                  className="p-3 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
                >
                  <Square size={20} />
                </button>
              ) : (
                <button
                  type="submit"
                  disabled={!message.trim()}
                  className="p-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors"
                >
                  <Send size={20} />
                </button>
              )}
            </div>
          </form>
          
          <div className="mt-2 text-xs text-gray-500 text-center">
            Using {LLM_PROVIDERS[selectedProvider as keyof typeof LLM_PROVIDERS].name} - {selectedModel}
          </div>
        </div>
      </div>
    </div>
  );
}
"use client";

import { useState, useRef, useEffect } from "react";
import { useSession } from "next-auth/react";
import { api } from "~/trpc/react";
import ChatSidebar from "./ChatSidebar";
import MessageList from "./MessageList";
import MessageInput from "./MessageInput";
import { type RouterOutputs } from "~/trpc/shared";

type Chat = RouterOutputs["chat"]["getAll"][0];
type Message = RouterOutputs["chat"]["getById"]["messages"][0];

export default function ChatInterface() {
  const { data: session } = useSession();
  const [selectedChatId, setSelectedChatId] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [isStreaming, setIsStreaming] = useState(false);
  const [streamingMessage, setStreamingMessage] = useState("");
  const abortControllerRef = useRef<AbortController | null>(null);

  const { data: chats, refetch: refetchChats } = api.chat.getAll.useQuery();
  const { data: selectedChat } = api.chat.getById.useQuery(
    { id: selectedChatId! },
    { enabled: !!selectedChatId }
  );

  const createChatMutation = api.chat.create.useMutation({
    onSuccess: (newChat) => {
      setSelectedChatId(newChat.id);
      refetchChats();
    },
  });

  const addMessageMutation = api.chat.addMessage.useMutation();

  useEffect(() => {
    if (selectedChat?.messages) {
      setMessages(selectedChat.messages);
    }
  }, [selectedChat]);

  const handleNewChat = () => {
    const title = `Chat ${new Date().toLocaleString()}`;
    createChatMutation.mutate({ title });
  };

  const handleSendMessage = async (content: string, provider: string, model: string) => {
    if (!selectedChatId || !content.trim()) return;

    // Add user message
    const userMessage: Message = {
      id: `temp-${Date.now()}`,
      content,
      role: "USER",
      chatId: selectedChatId,
      userId: session?.user?.id || "",
      attachments: [],
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);

    // Save user message to database
    try {
      await addMessageMutation.mutateAsync({
        chatId: selectedChatId,
        content,
        role: "USER",
      });
    } catch (error) {
      console.error("Failed to save user message:", error);
    }

    // Prepare messages for API
    const apiMessages = [...messages, userMessage].map(msg => ({
      role: msg.role.toLowerCase(),
      content: msg.content,
    }));

    setIsStreaming(true);
    setStreamingMessage("");

    // Create abort controller for this request
    abortControllerRef.current = new AbortController();

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          messages: apiMessages,
          provider,
          model,
        }),
        signal: abortControllerRef.current.signal,
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const contentType = response.headers.get("content-type");
      
      if (contentType?.includes("text/event-stream")) {
        // Handle streaming response
        const reader = response.body?.getReader();
        const decoder = new TextDecoder();
        let accumulatedContent = "";

        if (reader) {
          try {
            while (true) {
              const { done, value } = await reader.read();
              if (done) break;

              const chunk = decoder.decode(value);
              const lines = chunk.split("\n");

              for (const line of lines) {
                if (line.startsWith("data: ")) {
                  try {
                    const data = JSON.parse(line.slice(6));
                    if (data.content) {
                      accumulatedContent += data.content;
                      setStreamingMessage(accumulatedContent);
                    }
                  } catch (e) {
                    // Ignore parsing errors
                  }
                }
              }
            }
          } finally {
            reader.releaseLock();
          }
        }

        // Save assistant message to database
        if (accumulatedContent) {
          const assistantMessage = await addMessageMutation.mutateAsync({
            chatId: selectedChatId,
            content: accumulatedContent,
            role: "ASSISTANT",
          });

          setMessages(prev => [...prev, assistantMessage]);
        }
      } else {
        // Handle non-streaming response
        const data = await response.json();
        const assistantMessage = await addMessageMutation.mutateAsync({
          chatId: selectedChatId,
          content: data.content,
          role: "ASSISTANT",
        });

        setMessages(prev => [...prev, assistantMessage]);
      }
    } catch (error: any) {
      if (error.name === "AbortError") {
        console.log("Request was aborted");
      } else {
        console.error("Error sending message:", error);
        // You might want to show an error message to the user here
      }
    } finally {
      setIsStreaming(false);
      setStreamingMessage("");
      abortControllerRef.current = null;
    }
  };

  const handleStopGeneration = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
  };

  if (!session?.user) {
    return <div>Loading...</div>;
  }

  return (
    <div className="flex h-screen bg-gray-100">
      <ChatSidebar
        chats={chats || []}
        selectedChatId={selectedChatId}
        onSelectChat={setSelectedChatId}
        onNewChat={handleNewChat}
        user={session.user}
      />
      
      <div className="flex-1 flex flex-col">
        {selectedChatId ? (
          <>
            <MessageList
              messages={messages}
              isStreaming={isStreaming}
              streamingMessage={streamingMessage}
            />
            <MessageInput
              onSendMessage={handleSendMessage}
              isStreaming={isStreaming}
              onStopGeneration={handleStopGeneration}
            />
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center">
            <div className="text-center">
              <h2 className="text-2xl font-semibold text-gray-700 mb-4">
                Welcome to T3 Chat
              </h2>
              <p className="text-gray-500 mb-6">
                Select a chat from the sidebar or create a new one to get started.
              </p>
              <button
                onClick={handleNewChat}
                className="px-6 py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
              >
                Start New Chat
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
"use client";

import { useEffect, useRef } from "react";
import { User, Bot } from "lucide-react";
import { type RouterOutputs } from "~/trpc/shared";

type Message = RouterOutputs["chat"]["getById"]["messages"][0];

interface MessageListProps {
  messages: Message[];
  isStreaming: boolean;
  streamingMessage: string;
}

export default function MessageList({
  messages,
  isStreaming,
  streamingMessage,
}: MessageListProps) {
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, streamingMessage]);

  return (
    <div className="flex-1 overflow-y-auto p-4 space-y-4 scrollbar-thin">
      {messages.map((message) => (
        <div
          key={message.id}
          className={`flex gap-3 ${
            message.role === "USER" ? "justify-end" : "justify-start"
          }`}
        >
          {message.role === "ASSISTANT" && (
            <div className="w-8 h-8 bg-indigo-600 rounded-full flex items-center justify-center flex-shrink-0">
              <Bot size={16} className="text-white" />
            </div>
          )}
          
          <div
            className={`max-w-3xl p-4 rounded-lg ${
              message.role === "USER"
                ? "bg-indigo-600 text-white"
                : "bg-white border border-gray-200"
            }`}
          >
            <div className="whitespace-pre-wrap break-words">
              {message.content}
            </div>
            
            {message.attachments && message.attachments.length > 0 && (
              <div className="mt-2 space-y-2">
                {message.attachments.map((attachment) => (
                  <div
                    key={attachment.id}
                    className="flex items-center gap-2 p-2 bg-gray-100 rounded"
                  >
                    <span className="text-sm font-medium">
                      {attachment.filename}
                    </span>
                    <span className="text-xs text-gray-500">
                      ({(attachment.size / 1024).toFixed(1)} KB)
                    </span>
                  </div>
                ))}
              </div>
            )}
            
            <div className="text-xs opacity-70 mt-2">
              {new Date(message.createdAt).toLocaleTimeString()}
            </div>
          </div>

          {message.role === "USER" && (
            <div className="w-8 h-8 bg-gray-600 rounded-full flex items-center justify-center flex-shrink-0">
              <User size={16} className="text-white" />
            </div>
          )}
        </div>
      ))}

      {/* Streaming message */}
      {isStreaming && (
        <div className="flex gap-3 justify-start">
          <div className="w-8 h-8 bg-indigo-600 rounded-full flex items-center justify-center flex-shrink-0">
            <Bot size={16} className="text-white" />
          </div>
          
          <div className="max-w-3xl p-4 rounded-lg bg-white border border-gray-200">
            <div className="whitespace-pre-wrap break-words">
              {streamingMessage}
              <span className="inline-block w-2 h-5 bg-gray-400 ml-1 animate-pulse" />
            </div>
          </div>
        </div>
      )}

      {/* Typing indicator when no streaming message */}
      {isStreaming && !streamingMessage && (
        <div className="flex gap-3 justify-start">
          <div className="w-8 h-8 bg-indigo-600 rounded-full flex items-center justify-center flex-shrink-0">
            <Bot size={16} className="text-white" />
          </div>
          
          <div className="max-w-3xl p-4 rounded-lg bg-white border border-gray-200">
            <div className="typing-indicator">
              <div className="typing-dot"></div>
              <div className="typing-dot"></div>
              <div className="typing-dot"></div>
            </div>
          </div>
        </div>
      )}

      <div ref={messagesEndRef} />
    </div>
  );
}